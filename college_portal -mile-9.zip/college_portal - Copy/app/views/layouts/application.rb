<% if notice %>
  <p class="alert alert-success"><%= notice %></p>
    <% elsif alert %>
  <p class="alert alert-danger"><%= alert %></p>
  <% else %>
    <% flash.each do |key, value| %>
      <%= content_tag(:p, value, class: "alert alert-#{key}") %>
    <% end %>
<% end %>