 class hi extends Thread
 {
 	void run{
 		for (int i=0;i<5 ;i++ ) {
 			System.out.println("hi");
 			
 		}
 	}
 }

  class hello extends Thread
 {
 	void run{
 		for (int i=0;i<5 ;i++ ) {
 			System.out.println("hello");
 			
 		}
 	}
 }

 class demo_th
 {
 	public static void main(String[] args)
 	{hi o1 = new hi();
 	 hello o2 = new hello();
 	 o1.run();
 	 o.run();
 	}

 }