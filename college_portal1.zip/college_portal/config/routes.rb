Rails.application.routes.draw do

root to: "static_pages#index"  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
resources :departments, only: [:index, :create, :new,:show]
resources :sections, only: [:index, :new, :create,:show]
resources :students, only: [:index, :new, :create,:show]
end
