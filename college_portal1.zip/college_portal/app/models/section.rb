class Section < ApplicationRecord
	 belongs_to :department
	 has_many :students, dependent: :destroy
	 validates :name, presence: true, uniqueness: true
  	validates :department_id, presence: true


	 before_create :name_order_sec
	 private

	def name_order_sec
	   self.name.upcase! 
	end
end
