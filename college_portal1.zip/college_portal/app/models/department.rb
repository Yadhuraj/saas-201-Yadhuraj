class Department < ApplicationRecord
	has_many :sections, dependent: :destroy
	has_many :students, :through => :sections, dependent: :destroy
	validates :name, presence: true, uniqueness: true

	before_create :name_order_dept
	
	 def name_order_dept
    	self.name.upcase!
   	 end



end
